﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TrSinntecPrueba.Models
{
    public class FrameworkWithLanguage
    {
        public string FrameworkName { get; set; }
        public string LanguageName { get; set; }
    }
}
